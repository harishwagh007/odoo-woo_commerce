{
    "name": "Shopify Connector",
    "version": "1.1.1",
    "summary": "Odoo to Shopify Connector",
    "author": "SDLC",
    "category": "Integration",
    "license": "LGPL-3",

    # =============================
    # DEPENDENCIES
    # =============================
    "depends": [
        "base",
        "web",
        "product",
        "sale_management",
        "contacts",
    ],

    # =============================
    # DATA FILES (LOAD ORDER MATTERS)
    # =============================
    "data": [
        # SECURITY
        "security/ir.model.access.csv",

        # ACTIONS (ALWAYS BEFORE MENUS)
        "views/shopify_dashboard_action.xml",
        "views/shopify_actions.xml",
        "views/shopify_sync_report_action.xml",

        # MENUS
        "views/shopify_menu.xml",
        "views/shopify_mapping_audit_menu.xml",

        # CORE VIEWS
        "views/shopify_instance_view.xml",
        "views/shopify_views.xml",
        "views/res_partner_view.xml",
        "views/product_category_view.xml",
        "views/sale_order_view.xml",

        # FIELD MAPPING
        "views/shopify_field_mapping_views.xml",
        "views/shopify_mapping_audit_views.xml",
        "views/shopify_mapping_test_popup.xml",
        "views/shopify_mapping_test_wizard_views.xml",
        "views/shopify_webhook_report_view.xml",

        # GIFT CARD
        "views/shopify_gift_card_view.xml",

        # REPORTS
        "views/shopify_sync_report_view.xml",
        "views/shopify_sync_report_template.xml",
        "views/shopify_inventory_report_views.xml",

        # CRON
        "data/shopify_cron.xml",
    ],

    # =============================
    # FRONTEND ASSETS (Odoo 18)
    # =============================
    "assets": {
        "web.assets_backend": [
            # JS
            "sdlc_shopify_full_fixed/static/src/js/shopify_dashboard.js",
            "sdlc_shopify_full_fixed/static/src/js/custom_widget_placeholder.js",
            # CSS
            "sdlc_shopify_full_fixed/static/src/css/dashboard.css",
            # QWeb templates (also load in backend to ensure availability)
            "sdlc_shopify_full_fixed/static/src/xml/shopify_dashboard.xml",
            "sdlc_shopify_full_fixed/static/src/xml/custom_widget_placeholder.xml",
        ],
        "web.assets_qweb": [
            "sdlc_shopify_full_fixed/static/src/xml/shopify_dashboard.xml",
            "sdlc_shopify_full_fixed/static/src/xml/custom_widget_placeholder.xml",
        ],
    },

    # =============================
    # APP CONFIG
    # =============================
    "installable": True,
    "application": True,
}
