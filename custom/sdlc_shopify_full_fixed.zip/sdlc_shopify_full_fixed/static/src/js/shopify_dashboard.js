/** @odoo-module **/

import { Component, onMounted, onWillStart, onWillUnmount, useState } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

export class ShopifyDashboard extends Component {
    setup() {
        this.orm = useService("orm");
        this.action = useService("action");
        this.state = useState({
            data: {},
            loading: true,
            error: null,
            filters: {
                dateRange: "30d",
                instanceId: null,
                dateCheck: "",
                dateFrom: "",
                dateTo: "",
                showCustomDates: false,
            },
            instances: [],
        });

        // ensure handler keeps component context
        this.openOrder = this.openOrder.bind(this);

        onWillStart(async () => {
            await this.loadInstances();
            await this.fetchData();
        });

        onMounted(() => {
            this.intervalId = setInterval(() => this.fetchData(true), 60000);
        });

        onWillUnmount(() => {
            if (this.intervalId) {
                clearInterval(this.intervalId);
            }
        });
    }

    async loadInstances() {
        const records = await this.orm.searchRead("shopify.instance", [], ["name"]);
        this.state.instances = records || [];
    }

    async fetchData(isAuto = false) {
        if (!isAuto) {
            this.state.loading = true;
        }
        this.state.error = null;
        try {
            const result = await this.orm.call(
                "shopify.dashboard",
                "get_dashboard_data",
                [],
                {
                    date_range: this.state.filters.dateRange,
                    instance_id: this.state.filters.instanceId || false,
                    date_check: this.state.filters.dateCheck || false,
                    date_from: this.state.filters.dateFrom || false,
                    date_to: this.state.filters.dateTo || false,
                }
            );
            this.state.data = result || {};
        } catch (e) {
            this.state.error = e && e.message ? e.message : "Failed to load dashboard";
        } finally {
            this.state.loading = false;
        }
    }

    onDateRangeChange(ev) {
        this.state.filters.dateRange = ev.target.value;
        this.state.filters.showCustomDates = ev.target.value === "custom";
        this.fetchData();
    }

    onInstanceChange(ev) {
        const val = ev.target.value;
        this.state.filters.instanceId = val ? parseInt(val) : null;
        this.fetchData();
    }

    onDateCheckChange(ev) {
        this.state.filters.dateCheck = ev.target.value;
        this.fetchData();
    }

    onDateFromChange(ev) {
        this.state.filters.dateFrom = ev.target.value;
        this.state.filters.dateRange = "custom";
        this.state.filters.showCustomDates = true;
        this.fetchData();
    }

    onDateToChange(ev) {
        this.state.filters.dateTo = ev.target.value;
        this.state.filters.dateRange = "custom";
        this.state.filters.showCustomDates = true;
        this.fetchData();
    }

    openOrder(orderId) {
        if (!orderId || !this.action) {
            return;
        }
        this.action.doAction({
            type: "ir.actions.act_window",
            res_model: "sale.order",
            res_id: orderId,
            views: [[false, "form"]],
            target: "current",
        });
    }

    manualRefresh() {
        this.fetchData();
    }
}

ShopifyDashboard.template = "shopify_dashboard_template";

registry.category("actions").add("shopify_dashboard", ShopifyDashboard);
