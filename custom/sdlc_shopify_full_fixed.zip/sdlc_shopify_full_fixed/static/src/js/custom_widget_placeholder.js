/** @odoo-module **/

import { Component } from "@odoo/owl";
import { registry } from "@web/core/registry";

// Minimal placeholder widget for views expecting "customContentKanbanLikeWidget"
class CustomContentKanbanLikeWidget extends Component {}
CustomContentKanbanLikeWidget.template = "sdlc_shopify_full_fixed.CustomContentKanbanLikeWidget";

registry
    .category("view_widgets")
    .add("customContentKanbanLikeWidget", { component: CustomContentKanbanLikeWidget });
