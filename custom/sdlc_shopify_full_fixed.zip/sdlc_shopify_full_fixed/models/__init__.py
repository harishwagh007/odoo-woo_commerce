from . import shopify_instance
from . import shopify_field_mapping

from . import product_template_inherit
from . import res_partner_inherit
from . import product_category_inherit
from . import sale_order_inherit
from . import sale_order_line

from . import shopify_gift_card
from . import shopify_sync_report
from . import shopify_sync_report_line
from . import shopify_sync_report_export

from . import shopify_dashboard
from . import shopify_mapping_audit
from . import shopify_mapping_test_wizard
from . import shopify_webhook_sync
from . import shopify_inventory
