from odoo import models, fields


class ShopifySyncReportLine(models.Model):
    _name = "shopify.sync.report.line"
    _description = "Shopify Sync Report Line"
    _order = "id desc"

    # -----------------------------------------------------
    # LINK TO MAIN REPORT
    # -----------------------------------------------------
    report_id = fields.Many2one(
        "shopify.sync.report",
        required=True,
        ondelete="cascade"
    )

    # -----------------------------------------------------
    # RECORD TYPE (what was synced)
    # -----------------------------------------------------
    record_type = fields.Selection([
        ("product", "Product"),
        ("customer", "Customer"),
        ("order", "Order"),
        ("category", "Category"),
        ("gift_card", "Gift Card"),
    ], required=True)

    # -----------------------------------------------------
    # SOURCE ACTION (CREATE / UPDATE / MANUAL / WEBHOOK / AUTO)
    # -----------------------------------------------------
    source_action = fields.Selection([
        ("product_create", "Product - Create in Shopify"),
        ("product_update", "Product - Update in Shopify"),

        ("customer_create", "Customer - Create in Shopify"),
        ("customer_update", "Customer - Update in Shopify"),

        ("order_create", "Order - Create in Shopify"),
        ("order_update", "Order - Update in Shopify"),

        ("category_create", "Category - Create in Shopify"),
        ("category_update", "Category - Update in Shopify"),

        ("gift_card_create", "Gift Card - Create"),
        ("gift_card_update", "Gift Card - Update"),

        # ⭐ IMPORTANT: Manual sync support
        ("manual", "Manual Sync"),

        # ⭐ OPTIONAL: Auto sync + Webhook support
        ("auto", "Auto Sync"),
        ("webhook", "Webhook Triggered"),

    ], string="Source Action", required=False, default="manual")

    # -----------------------------------------------------
    # SYNC DETAILS
    # -----------------------------------------------------
    shopify_id = fields.Char(string="Shopify ID")
    name = fields.Char(string="Record Name")

    status = fields.Selection([
        ("success", "Success"),
        ("error", "Error"),
    ], required=True)

    error_message = fields.Text(string="Error Message")
