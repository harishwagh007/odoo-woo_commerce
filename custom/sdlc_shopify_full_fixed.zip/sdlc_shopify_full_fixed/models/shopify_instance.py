from odoo import models, fields
from odoo.exceptions import UserError
import requests
import base64
import logging
from datetime import timedelta
import calendar
from odoo import fields as odoo_fields

_logger = logging.getLogger(__name__)


class ShopifyInstance(models.Model):
    _name = "shopify.instance"
    _description = "Shopify Instance"

    # ==================================================
    # BASIC CONFIG
    # ==================================================
    name = fields.Char(required=True)
    shop_url = fields.Char(required=True)
    api_version = fields.Char(default="2025-10", required=True)
    access_token = fields.Char(required=True)
    active = fields.Boolean(default=True)
    notification_email = fields.Char("Notification Email")

     # ---------------- PRODUCT WEBHOOK ----------------
    webhook_product_create = fields.Boolean("Product Create Sync", default=True)
    webhook_product_update = fields.Boolean("Product Update Sync", default=False)

    # ---------------- CUSTOMER WEBHOOK ----------------
    webhook_customer_create = fields.Boolean(default=True)
    webhook_customer_update = fields.Boolean(default=True)

    # ---------------- ORDER WEBHOOK ----------------
    webhook_order_create = fields.Boolean(default=True)
    webhook_order_update = fields.Boolean(default=True)

    # ---------------- CATEGORY WEBHOOK ----------------
    webhook_category_create = fields.Boolean(default=True)
    webhook_category_update = fields.Boolean(default=True)

    # ---------------- GIFTCARD WEBHOOK ----------------
    webhook_giftcard_create = fields.Boolean(default=True)
    webhook_giftcard_update = fields.Boolean(default=True)

    # ==================================================
    # AUTO SYNC CONFIG (BASE)
    # ==================================================
    auto_product_sync = fields.Boolean("Auto Product Sync")
    auto_product_interval = fields.Integer(default=1)
    product_cron_id = fields.Many2one("ir.cron", readonly=True)

    auto_customer_sync = fields.Boolean("Auto Customer Sync")
    auto_customer_interval = fields.Integer(default=1)
    customer_cron_id = fields.Many2one("ir.cron", readonly=True)

    auto_order_sync = fields.Boolean("Auto Order Sync")
    auto_order_interval = fields.Integer(default=1)
    order_cron_id = fields.Many2one("ir.cron", readonly=True)

    auto_category_sync = fields.Boolean("Auto Category Sync")
    auto_category_interval = fields.Integer(default=1)
    category_cron_id = fields.Many2one("ir.cron", readonly=True)

    auto_giftcard_sync = fields.Boolean("Auto Gift Card Sync")
    auto_giftcard_interval = fields.Integer(default=1)
    giftcard_cron_id = fields.Many2one("ir.cron", readonly=True)

    last_product_sync_at = fields.Datetime()
    last_customer_sync_at = fields.Datetime()
    last_order_sync_at = fields.Datetime()
    last_category_sync_at = fields.Datetime()
    last_giftcard_sync_at = fields.Datetime()

    # ==================================================
    # FREQUENCY DROPDOWN
    # ==================================================
    INTERVAL_TYPE = [
        ("hours", "Hourly"),
        ("days", "Daily"),
        ("weeks", "Weekly"),
        ("months", "Monthly"),
    ]

    auto_product_interval_type = fields.Selection(INTERVAL_TYPE, default="hours")
    auto_customer_interval_type = fields.Selection(INTERVAL_TYPE, default="hours")
    auto_order_interval_type = fields.Selection(INTERVAL_TYPE, default="hours")
    auto_category_interval_type = fields.Selection(INTERVAL_TYPE, default="days")
    auto_giftcard_interval_type = fields.Selection(INTERVAL_TYPE, default="days")

    # ==================================================
    # ADVANCED SCHEDULER OPTIONS
    # ==================================================
    auto_sync_hour = fields.Selection(
        [(str(i), f"{i:02d}") for i in range(0, 24)], string="Hour", default="0"
    )

    auto_sync_minute = fields.Selection(
        [(str(i), f"{i:02d}") for i in range(0, 60, 5)], string="Minute", default="0"
    )

    auto_sync_weekday = fields.Selection(
        [
            ("0", "Monday"),
            ("1", "Tuesday"),
            ("2", "Wednesday"),
            ("3", "Thursday"),
            ("4", "Friday"),
            ("5", "Saturday"),
            ("6", "Sunday"),
        ],
        string="Weekday",
        default="0",
    )

    auto_sync_month_day = fields.Selection(
        [(str(i), str(i)) for i in range(1, 32)], string="Day of Month", default="1"
    )

    # ==================================================
    # TEST CONNECTION
    # ==================================================
    def action_test_connection(self):
        self.ensure_one()
        url = f"{self.shop_url.rstrip('/')}/admin/api/{self.api_version}/shop.json"
        headers = {
            "X-Shopify-Access-Token": self.access_token,
            "Content-Type": "application/json",
        }
        res = requests.get(url, headers=headers, timeout=20)
        if res.status_code != 200:
            raise UserError(res.text)

        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": "Success",
                "message": "Shopify Connected Successfully",
                "type": "success",
            },
        }

    # ==================================================
    # SHOPIFY HELPERS
    # ==================================================
    def _headers(self):
        self.ensure_one()
        return {
            "Content-Type": "application/json",
            "X-Shopify-Access-Token": self.access_token,
        }

    def _get(self, endpoint, params=None):
        self.ensure_one()
        url = f"{self.shop_url.rstrip('/')}/admin/api/{self.api_version}/{endpoint}"
        res = requests.get(
            url, headers=self._headers(), params=params or {}, timeout=30
        )
        if res.status_code != 200:
            raise UserError(res.text)
        return res.json()

    # ==================================================
    # REPORT HELPERS
    # ==================================================
    def _open_report(self, sync_type):
        return (
            self.env["shopify.sync.report"]
            .sudo()
            .create(
                {
                    "instance_id": self.id,
                    "sync_type": sync_type,
                    "start_time": fields.Datetime.now(),
                    "total_records": 0,
                    "success_count": 0,
                    "error_count": 0,
                }
            )
        )

    def _close_report(self, report, total, success, error):
        report.write(
            {
                "end_time": fields.Datetime.now(),
                "total_records": total,
                "success_count": success,
                "error_count": error,
            }
        )

    # ==================================================
    # NEXT CALL CALCULATION
    # ==================================================
    def _calculate_nextcall(self, interval_type, interval_number=1):
        now = fields.Datetime.now()

        hour = int(self.auto_sync_hour or 0)
        minute = int(self.auto_sync_minute or 0)

        if interval_type == "hours":
            return now + timedelta(hours=interval_number)

        if interval_type == "days":
            base = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if base <= now:
                base += timedelta(days=interval_number)
            return base

        if interval_type == "weeks":
            weekday = int(self.auto_sync_weekday or 0)
            base = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            days_ahead = weekday - base.weekday()
            if days_ahead <= 0:
                days_ahead += 7
            return base + timedelta(days=days_ahead)

        if interval_type == "months":
            year = now.year
            month = now.month
            day = int(self.auto_sync_month_day or 1)

            last_day = calendar.monthrange(year, month)[1]
            day = min(day, last_day)

            base = now.replace(
                year=year,
                month=month,
                day=day,
                hour=hour,
                minute=minute,
                second=0,
                microsecond=0,
            )

            if base <= now:
                month += interval_number
                if month > 12:
                    month -= 12
                    year += 1

                last_day = calendar.monthrange(year, month)[1]
                day = min(day, last_day)
                base = base.replace(year=year, month=month, day=day)

            return base

        return now + timedelta(hours=1)

    # ==================================================
    # SYNC METHODS (WRAPPER for MULTI INSTANCES)
    # ==================================================
    def _sync_products(self, mode="manual"):
        for instance in self:
            instance._sync_products_single(mode=mode)

    def _sync_products_single(self, mode="manual"):
        self.ensure_one()
        ReportLine = self.env["shopify.sync.report.line"].sudo()
        report = self._open_report("product")

        total = success = error = 0
        products = self._get("products.json", {"limit": 250}).get("products", [])
        Product = self.env["product.template"].sudo()

        for p in products:
            total += 1
            pid = str(p["id"])
            try:
                vals = {
                    "name": p.get("title") or f"Shopify Product {pid}",
                    "shopify_product_id": pid,
                    "type": "consu",
                    "description_sale": p.get("body_html") or False,
                }

                variants = p.get("variants") or []
                if variants:
                    vals["list_price"] = float(variants[0].get("price", 0.0))

                # Pull first product image from Shopify into Odoo
                images = p.get("images") or []
                if images:
                    src = (images[0] or {}).get("src")
                    if src:
                        try:
                            resp = requests.get(src, timeout=10)
                            if resp.status_code == 200:
                                vals["image_1920"] = base64.b64encode(resp.content)
                        except Exception:
                            pass

                prod = Product.search([("shopify_product_id", "=", pid)], limit=1)
                if prod:
                    prod.write(vals)
                else:
                    Product.create(vals)

                success += 1
                ReportLine.create(
                    {
                        "report_id": report.id,
                        "record_type": "product",
                        "shopify_id": pid,
                        "name": vals["name"],
                        "status": "success",
                    }
                )
            except Exception as e:
                error += 1
                ReportLine.create(
                    {
                        "report_id": report.id,
                        "record_type": "product",
                        "shopify_id": pid,
                        "status": "error",
                        "error_message": str(e),
                    }
                )

        self._close_report(report, total, success, error)

    def _sync_customers(self, mode="manual"):
        for instance in self:
            instance._sync_customers_single(mode=mode)

    def _sync_customers_single(self, mode="manual"):
        self.ensure_one()

        ReportLine = self.env["shopify.sync.report.line"].sudo()
        Partner = self.env["res.partner"].sudo()
        report = self._open_report("customer")

        total = success = error = 0
        customers = self._get("customers.json", {"limit": 250}).get("customers", [])

        for c in customers:
            total += 1
            cid = str(c.get("id"))

            try:
                name = (
                    f"{c.get('first_name','')} {c.get('last_name','')}".strip()
                    or c.get("email")
                    or f"Shopify Customer {cid}"
                )

                email = c.get("email") or False

                vals = {
                    "name": name,
                    "email": email,
                    "shopify_customer_id": cid,
                    "customer_rank": 1,
                }

                partner = Partner.search([("shopify_customer_id", "=", cid)], limit=1)

                if partner:
                    partner.write(vals)
                else:
                    Partner.create(vals)

                success += 1
                ReportLine.create(
                    {
                        "report_id": report.id,
                        "record_type": "customer",
                        "shopify_id": cid,
                        "name": name,
                        "status": "success",
                    }
                )

            except Exception as e:
                self.env.cr.rollback()

                error += 1
                ReportLine.create(
                    {
                        "report_id": report.id,
                        "record_type": "customer",
                        "shopify_id": cid,
                        "status": "error",
                        "error_message": str(e),
                    }
                )

        self._close_report(report, total, success, error)

    def _sync_orders(self, mode="manual"):
        for instance in self:
            instance._sync_orders_single(mode=mode)

    def _sync_orders_single(self, mode="manual"):
        self.ensure_one()
        ReportLine = self.env["shopify.sync.report.line"].sudo()
        report = self._open_report("order")

        total = success = error = 0
        orders = self._get("orders.json", {"limit": 50, "status": "any"}).get(
            "orders", []
        )
        Order = self.env["sale.order"].sudo()

        for o in orders:
            total += 1
            oid = str(o["id"])
            try:
                # Isolate each order so one bad payload doesn't abort the whole sync
                with self.env.cr.savepoint():
                    order = Order.map_shopify_order_to_odoo(o, instance=self)

                success += 1
                ReportLine.create(
                    {
                        "report_id": report.id,
                        "record_type": "order",
                        "shopify_id": oid,
                        "name": order.name if order else False,
                        "status": "success",
                    }
                )
            except Exception as e:
                _logger.exception("Shopify order import failed for %s", oid)
                error += 1
                ReportLine.create(
                    {
                        "report_id": report.id,
                        "record_type": "order",
                        "shopify_id": oid,
                        "status": "error",
                        "error_message": str(e),
                    }
                )

        self._close_report(report, total, success, error)

    def _sync_categories(self, mode="manual"):
        for instance in self:
            instance._sync_categories_single(mode=mode)

    def _sync_categories_single(self, mode="manual"):
        self.ensure_one()

        ReportLine = self.env["shopify.sync.report.line"].sudo()
        Category = self.env["product.category"].sudo()

        report = self._open_report("category")

        total = success = error = 0
        categories = self._get(
            "custom_collections.json", {"limit": 250}
        ).get("custom_collections", [])

        for c in categories:
            total += 1
            cid = str(c.get("id"))

            try:
                vals = {
                    "name": c.get("title") or f"Shopify Category {cid}",
                    "shopify_collection_id": cid,
                }

                category = Category.search(
                    [("shopify_collection_id", "=", cid)],
                    limit=1,
                )

                if category:
                    category.write(vals)
                else:
                    Category.create(vals)

                success += 1
                ReportLine.create(
                    {
                        "report_id": report.id,
                        "record_type": "category",
                        "shopify_id": cid,
                        "name": vals["name"],
                        "status": "success",
                    }
                )

            except Exception as e:
                error += 1
                ReportLine.create(
                    {
                        "report_id": report.id,
                        "record_type": "category",
                        "shopify_id": cid,
                        "status": "error",
                        "error_message": str(e),
                    }
                )

        self._close_report(report, total, success, error)

    def _sync_gift_cards(self, mode="manual"):
        for instance in self:
            instance._sync_gift_cards_single(mode=mode)

    def _sync_gift_cards_single(self, mode="manual"):
        self.ensure_one()

        ReportLine = self.env["shopify.sync.report.line"].sudo()
        GiftCard = self.env["shopify.gift.card"].sudo()

        report = self._open_report("gift_card")

        total = success = error = 0
        gift_cards = self._get("gift_cards.json", {"limit": 250}).get("gift_cards", [])

        for g in gift_cards:
            total += 1
            gid = str(g.get("id"))

            try:
                vals = {
                    "instance_id": self.id,
                    "shopify_gift_card_id": gid,
                    "code": g.get("code"),
                    "value": float(g.get("initial_value") or 0.0),
                    "balance": float(g.get("balance") or 0.0),
                    "currency": g.get("currency") or "INR",
                    "active": not g.get("disabled", False),
                    "expiry_date": g.get("expires_on") or False,
                    "state": g.get("status") or g.get("state"),
                }

                gift = GiftCard.search(
                    [
                        ("shopify_gift_card_id", "=", gid),
                        ("instance_id", "=", self.id),
                    ],
                    limit=1,
                )

                if gift:
                    gift.write(vals)
                else:
                    GiftCard.create(vals)

                success += 1
                ReportLine.create(
                    {
                        "report_id": report.id,
                        "record_type": "gift_card",
                        "shopify_id": gid,
                        "name": g.get("code"),
                        "status": "success",
                    }
                )

            except Exception as e:
                error += 1
                ReportLine.create(
                    {
                        "report_id": report.id,
                        "record_type": "gift_card",
                        "shopify_id": gid,
                        "status": "error",
                        "error_message": str(e),
                    }
                )

        self._close_report(report, total, success, error)

    # ==================================================
    # CHECK IF TIME TO SYNC
    # ==================================================
    def _is_time_to_sync(self, last_sync, interval_type, interval_number):
        if not last_sync:
            return True

        now = fields.Datetime.now()

        if interval_type == "hours":
            return now >= last_sync + timedelta(hours=interval_number)

        if interval_type == "days":
            return now >= last_sync + timedelta(days=interval_number)

        if interval_type == "weeks":
            return now >= last_sync + timedelta(weeks=interval_number)

        if interval_type == "months":
            return now >= last_sync + timedelta(days=30 * interval_number)

        return False

    # ==================================================
    # BUTTON ACTIONS
    # ==================================================
    def action_sync_products(self):
        self._sync_products()
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": "Success",
                "message": "Product sync finished",
                "type": "success",
            },
        }

    def action_sync_customers(self):
        self._sync_customers()
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": "Success",
                "message": "Customer sync finished",
                "type": "success",
            },
        }

    def action_sync_orders(self):
        self._sync_orders()
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": "Success",
                "message": "Order sync finished",
                "type": "success",
            },
        }

    def action_sync_categories(self):
        self._sync_categories()
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": "Success",
                "message": "Category sync finished",
                "type": "success",
            },
        }

    def action_sync_gift_cards(self):
        self._sync_gift_cards()
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": "Success",
                "message": "Gift Card sync finished",
                "type": "success",
            },
        }

    def action_inventory_report(self):
        """Rebuild and open the inventory report for this instance."""
        self.ensure_one()
        threshold = 0.0
        self.env["shopify.inventory.report"].sudo().rebuild_inventory_report(
            instance=self, threshold=threshold
        )
        action = self.env.ref(
            "sdlc_shopify_full_fixed.action_shopify_inventory_report"
        ).read()[0]
        action["domain"] = [("instance_id", "=", self.id)]
        action.setdefault("context", {})
        action["context"].update({"default_instance_id": self.id})
        return action

    # ==================================================
    # CRON : AUTO SYNC
    # ==================================================
    def cron_auto_sync(self):
        now = fields.Datetime.now()
        instances = self.search([("active", "=", True)])

        for instance in instances:
            if instance.auto_product_sync and instance._is_time_to_sync(
                instance.last_product_sync_at,
                instance.auto_product_interval_type,
                instance.auto_product_interval,
            ):
                instance._sync_products(mode="cron")
                instance.last_product_sync_at = now

            if instance.auto_customer_sync and instance._is_time_to_sync(
                instance.last_customer_sync_at,
                instance.auto_customer_interval_type,
                instance.auto_customer_interval,
            ):
                instance._sync_customers(mode="cron")
                instance.last_customer_sync_at = now

            if instance.auto_order_sync and instance._is_time_to_sync(
                instance.last_order_sync_at,
                instance.auto_order_interval_type,
                instance.auto_order_interval,
            ):
                instance._sync_orders(mode="cron")
                instance.last_order_sync_at = now

            if instance.auto_category_sync and instance._is_time_to_sync(
                instance.last_category_sync_at,
                instance.auto_category_interval_type,
                instance.auto_category_interval,
            ):
                instance._sync_categories(mode="cron")
                instance.last_category_sync_at = now

            if instance.auto_giftcard_sync and instance._is_time_to_sync(
                instance.last_giftcard_sync_at,
                instance.auto_giftcard_interval_type,
                instance.auto_giftcard_interval,
            ):
                instance._sync_gift_cards(mode="cron")
                instance.last_giftcard_sync_at = now

        return True
