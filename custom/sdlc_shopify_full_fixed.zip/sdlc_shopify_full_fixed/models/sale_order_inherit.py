from odoo import models, fields, api, _
from odoo.exceptions import UserError
import requests
import logging
import json

_logger = logging.getLogger(__name__)


class SaleOrder(models.Model):
    _inherit = "sale.order"

    shopify_order_id = fields.Char("Shopify Order ID", readonly=True)
    shopify_instance_id = fields.Many2one(
        "shopify.instance",
        string="Shopify Instance",
        readonly=False,
        copy=False,
    )
    quotation_document_ids = fields.Many2many(
        "ir.attachment",
        string="Documents",
        copy=False,
    )

    customizable_pdf_form_fields = fields.Json(
        string="Custom PDF Fields",
        copy=False,
        default=list,
    )

    is_pdf_quote_builder_available = fields.Boolean(
        string="PDF Quote Builder Available",
        compute="_compute_pdf_quote_available",
        store=False,
    )

    def _compute_pdf_quote_available(self):
        for order in self:
            order.is_pdf_quote_builder_available = False

    gift_card_applied = fields.Boolean(
        string="Gift Card Applied",
        default=False,
        copy=False,
        help="Prevents double gift card deduction on Shopify re-sync"
    )

    gift_card_refund_processed = fields.Boolean(
        string="Gift Card Refund Processed",
        default=False,
        copy=False,
        help="Prevents double gift card restore on refund webhook"
    )

    # ---------------------------------------------------
    # SAFE LINE DELETE (ODOO 18 FIX)
    # ---------------------------------------------------
    def safe_delete_line(self, line):
        self.ensure_one()

        if self.state in ["sale", "sent", "done"]:
            self.action_unlock()

        line.unlink()

        if self.state == "draft":
            self.action_confirm()

    # ---------------------------------------------------
    # BUILD SHOPIFY PAYLOAD
    # ---------------------------------------------------
    def _prepare_shopify_order_payload(self):
        self.ensure_one()

        payload = {
            "line_items": [],
            "customer": {},
        }

        partner = self.partner_id
        if partner:
            payload["customer"] = {
                "email": partner.email or "guest@example.com",
                "first_name": (partner.name or "Customer").split(" ")[0],
                "last_name": " ".join((partner.name or "").split(" ")[1:]) or "Shopify",
            }

        for line in self.order_line:
            product = line.product_id
            item = {
                "quantity": int(line.product_uom_qty),
                "title": product.name,
                "price": str(line.price_unit),
            }

            # If a variant id is known, send it, but keep price/title to satisfy Shopify
            if product.shopify_product_id and str(product.shopify_product_id).isdigit():
                item["variant_id"] = int(product.shopify_product_id)

            payload["line_items"].append(item)

        return {"order": payload}

    # ---------------------------------------------------
    # ✅ INTERNAL HELPER: ORDER SYNC REPORT (NEW ✅)
    # ---------------------------------------------------
    def _create_order_sync_report(self, instance, payload, response_text, status, source_action):
        Report = self.env["shopify.sync.report"]
        Line = self.env["shopify.sync.report.line"]

        report = Report.create({
            "instance_id": instance.id,
            "sync_type": "order",
            "total_records": 1,
            "success_count": 1 if status == "success" else 0,
            "error_count": 1 if status == "error" else 0,
        })

        Line.create({
            "report_id": report.id,
            "record_type": "order",
            "source_action": source_action,
            "shopify_id": self.shopify_order_id or "",
            "name": self.name,
            "status": status,
            "error_message": response_text if status == "error" else False,
        })

    # ---------------------------------------------------
    # CREATE ORDER ON SHOPIFY ✅ OLD LOGIC + REPORT
    # ---------------------------------------------------
    def action_create_shopify_order(self):
        self.ensure_one()

        instance = self.shopify_instance_id or self.env["shopify.instance"].search(
            [("active", "=", True)], limit=1
        )
        if not instance:
            raise UserError("Please configure Shopify Instance first.")
        self.shopify_instance_id = instance.id

        if not self.order_line:
            raise UserError("Order has no lines!")

        payload = self._prepare_shopify_order_payload()
        payload["order"]["financial_status"] = "paid"

        url = f"{instance.shop_url.rstrip('/')}/admin/api/{instance.api_version}/orders.json"
        headers = {
            "Content-Type": "application/json",
            "X-Shopify-Access-Token": instance.access_token,
        }

        response = requests.post(url, json=payload, headers=headers)
        if response.status_code not in (200, 201):
            self._create_order_sync_report(
                instance, payload, response.text, "error", "order_create"
            )
            raise UserError(f"Shopify Error: {response.text}")

        self.shopify_order_id = response.json()["order"]["id"]

        self._create_order_sync_report(
            instance, payload, response.text, "success", "order_create"
        )

        return {
            "effect": {
                "fadeout": "slow",
                "message": _("✅ Order created successfully in Shopify!"),
                "type": "rainbow_man",
            }
        }

    # ---------------------------------------------------
    # UPDATE ORDER ON SHOPIFY ✅ OLD LOGIC + REPORT
    # ---------------------------------------------------
    def action_update_shopify_order(self):
        self.ensure_one()

        if not self.shopify_order_id:
            raise UserError("This order is not linked with Shopify.")

        instance = self.shopify_instance_id or self.env["shopify.instance"].search(
            [("active", "=", True)], limit=1
        )
        if not instance:
            raise UserError("Shopify instance not configured.")

        line_items = []
        for line in self.order_line:
            if not line.product_id.shopify_product_id:
                continue

            line_items.append({
                "variant_id": int(line.product_id.shopify_product_id),
                "quantity": int(line.product_uom_qty),
                "price": str(line.price_unit),
            })

        if not line_items:
            raise UserError("No Shopify products found in order lines.")

        payload = {
            "order": {
                "id": int(self.shopify_order_id),
                "line_items": line_items,
                "note": f"Updated from Odoo Order {self.name}",
            }
        }

        url = f"{instance.shop_url.rstrip('/')}/admin/api/{instance.api_version}/orders/{self.shopify_order_id}.json"
        headers = {
            "Content-Type": "application/json",
            "X-Shopify-Access-Token": instance.access_token,
        }

        response = requests.put(url, json=payload, headers=headers)
        if response.status_code not in (200, 201):
            self._create_order_sync_report(
                instance, payload, response.text, "error", "order_update"
            )
            raise UserError(f"Shopify Update Failed:\n{response.text}")

        self._create_order_sync_report(
            instance, payload, response.text, "success", "order_update"
        )

        return {
            "effect": {
                "fadeout": "slow",
                "message": "✅ Order updated successfully in Shopify",
                "type": "rainbow_man",
            }
        }

    # ---------------------------------------------------
    # SHOPIFY → ODOO ORDER SYNC (GIFT CARD LOGIC UNCHANGED)
    # ---------------------------------------------------
    @api.model
    def map_shopify_order_to_odoo(self, order_data, instance=None):
        """Create or update an Odoo sale order from a Shopify order payload."""
        order_data = order_data or {}
        if isinstance(order_data, dict) and order_data.get("order"):
            order_data = order_data.get("order") or {}
        if isinstance(order_data, dict) and order_data.get("orders"):
            # If a list was passed accidentally, pick first
            orders_list = order_data.get("orders") or []
            if orders_list:
                order_data = orders_list[0]
        _logger.info("SHOPIFY ORDER PAYLOAD KEYS -> %s", list(order_data.keys()))
        instance = instance or self.env["shopify.instance"].sudo().search(
            [("active", "=", True)], limit=1
        )

        Partner = self.env["res.partner"].sudo()
        ProductTemplate = self.env["product.template"].sudo()

        def _float(val):
            try:
                return float(val or 0.0)
            except Exception:
                return 0.0

        def _resolve_country_state(addr):
            country = None
            state = None
            country_code = (addr or {}).get("country_code") or (addr or {}).get("country")
            state_code = (addr or {}).get("province_code") or (addr or {}).get("province")
            if country_code:
                country = self.env["res.country"].sudo().search(
                    [("code", "=", country_code)], limit=1
                )
            if state_code and country:
                state = self.env["res.country.state"].sudo().search(
                    [("code", "=", state_code), ("country_id", "=", country.id)],
                    limit=1,
                )
            return country, state

        def _get_partner():
            customer = order_data.get("customer") or {}
            # Use existing customer mapping helper for consistency
            partner_vals = Partner.map_shopify_customer_to_odoo(customer, instance=instance)
            shopify_customer_id = partner_vals.get("shopify_customer_id")
            email = partner_vals.get("email") or order_data.get("email")

            partner = False
            if shopify_customer_id:
                partner = Partner.search(
                    [("shopify_customer_id", "=", str(shopify_customer_id))],
                    limit=1,
                )
            if not partner and email:
                partner = Partner.search([("email", "=", email)], limit=1)

            if partner:
                partner.write({k: v for k, v in partner_vals.items() if v})
            else:
                partner = Partner.create({k: v for k, v in partner_vals.items() if v})
            return partner

        def _get_child_address(parent, addr, addr_type):
            if not parent or not addr:
                return parent
            country, state = _resolve_country_state(addr)
            vals = {
                "parent_id": parent.id,
                "type": addr_type,
                "name": addr.get("name") or parent.name,
                "street": addr.get("address1"),
                "street2": addr.get("address2"),
                "city": addr.get("city"),
                "zip": addr.get("zip"),
                "phone": addr.get("phone") or parent.phone,
                "country_id": country.id if country else False,
                "state_id": state.id if state else False,
            }
            existing = Partner.search(
                [
                    ("parent_id", "=", parent.id),
                    ("type", "=", addr_type),
                    ("street", "=", vals.get("street")),
                    ("zip", "=", vals.get("zip")),
                    ("country_id", "=", vals.get("country_id") or False),
                ],
                limit=1,
            )
            if existing:
                existing.write({k: v for k, v in vals.items() if v})
                return existing
            return Partner.create({k: v for k, v in vals.items() if v})

        partner = _get_partner()
        shipping_partner = _get_child_address(
            partner, order_data.get("shipping_address") or {}, "delivery"
        )
        invoice_partner = _get_child_address(
            partner, order_data.get("billing_address") or {}, "invoice"
        ) or partner

        currency = False
        currency_code = order_data.get("currency")
        if currency_code:
            currency = self.env["res.currency"].sudo().search([("name", "=", currency_code)], limit=1)

        def _parse_dt(dt_val):
            """Parse Shopify ISO datetime safely into Odoo datetime."""
            if not dt_val:
                return False
            try:
                return fields.Datetime.to_datetime(dt_val)
            except Exception:
                _logger.warning("Unable to parse Shopify datetime: %s", dt_val)
                return False

        order_vals = {
            "shopify_order_id": str(order_data.get("id")),
            "partner_id": partner.id if partner else False,
            "partner_invoice_id": invoice_partner.id if invoice_partner else partner.id if partner else False,
            "partner_shipping_id": shipping_partner.id if shipping_partner else partner.id if partner else False,
            "client_order_ref": order_data.get("name"),
            "origin": order_data.get("order_number") or order_data.get("name"),
            "note": order_data.get("note"),
            "shopify_instance_id": instance.id if instance else False,
        }
        # assign salesperson to the current user so records appear in "My" views
        if self.env.uid:
            order_vals["user_id"] = self.env.uid
        if currency:
            order_vals["currency_id"] = currency.id
        if partner and partner.property_product_pricelist:
            order_vals["pricelist_id"] = partner.property_product_pricelist.id
        parsed_dt = _parse_dt(order_data.get("created_at") or order_data.get("processed_at"))
        if parsed_dt:
            order_vals["date_order"] = parsed_dt

        order = self.search(
            [("shopify_order_id", "=", order_vals["shopify_order_id"])],
            limit=1
        )
        if order:
            order.write(order_vals)
        else:
            order = self.create(order_vals)

        # Ensure order is editable, then rebuild non gift card lines
        if order.state not in ("draft", "sent"):
            order.action_unlock()

        order.order_line.filtered(lambda l: not getattr(l, "is_gift_card", False)).unlink()

        # Fallback products for generic lines
        def _fallback_product(code, name):
            tmpl = ProductTemplate.search([("default_code", "=", code)], limit=1)
            if not tmpl:
                tmpl = ProductTemplate.create({
                    "name": name,
                    "default_code": code,
                    "type": "service",
                })
            return tmpl.product_variant_id

        generic_product = _fallback_product("SHOPIFY_GENERIC", "Shopify Item")
        shipping_product = _fallback_product("SHOPIFY_SHIPPING", "Shopify Shipping")
        discount_product = _fallback_product("SHOPIFY_DISCOUNT", "Shopify Discount")
        adjust_product = _fallback_product("SHOPIFY_ADJUST", "Shopify Adjustment")
        tax_cache = {}

        def _ensure_tax(rate, title):
            """Find or create a tax matching the Shopify rate."""
            percent = round(rate * 100, 4)
            cache_key = f"{percent}"
            if cache_key in tax_cache:
                return tax_cache[cache_key]
            tax = self.env["account.tax"].sudo().search(
                [("type_tax_use", "in", ["sale", "all"]), ("amount", "=", percent)],
                limit=1,
            )
            if not tax:
                tax = self.env["account.tax"].sudo().create({
                    "name": title or f"Shopify Tax {percent}%",
                    "amount": percent,
                    "amount_type": "percent",
                    "type_tax_use": "sale",
                })
            tax_cache[cache_key] = tax
            return tax

        # Order item lines
        for item in order_data.get("line_items", []):
            qty = _float(item.get("quantity"))
            if not qty:
                continue
            unit_price = _float(item.get("price"))
            discount_alloc = sum(
                [_float(alloc.get("amount")) for alloc in item.get("discount_allocations", [])]
            )
            if discount_alloc:
                unit_price -= (discount_alloc / qty) if qty else discount_alloc

            product = False
            product_id = item.get("product_id")
            if product_id:
                tmpl = ProductTemplate.search(
                    [("shopify_product_id", "=", str(product_id))],
                    limit=1,
                )
                if tmpl:
                    product = tmpl.product_variant_id

            tax_ids = []
            for t in item.get("tax_lines", []):
                rate = _float(t.get("rate"))
                if rate:
                    tax_ids.append(_ensure_tax(rate, t.get("title")).id)

            order.order_line.create({
                "order_id": order.id,
                "name": item.get("name") or item.get("title") or "Shopify Item",
                "product_uom_qty": qty,
                "price_unit": unit_price,
                "product_id": product.id if product else generic_product.id,
                "tax_id": [(6, 0, tax_ids)],
                "customer_lead": 0.0,
            })

        # Shipping lines
        for ship in order_data.get("shipping_lines", []):
            ship_amount = _float(ship.get("price"))
            if not ship_amount:
                continue
            tax_ids = []
            for t in ship.get("tax_lines", []):
                rate = _float(t.get("rate"))
                if rate:
                    tax_ids.append(_ensure_tax(rate, t.get("title")).id)
            order.order_line.create({
                "order_id": order.id,
                "name": ship.get("title") or "Shipping",
                "product_uom_qty": 1,
                "price_unit": ship_amount,
                "product_id": shipping_product.id,
                "tax_id": [(6, 0, tax_ids)],
            })

        # Discount codes (as negative lines)
        for disc in order_data.get("discount_codes", []):
            disc_amount = _float(disc.get("amount"))
            if not disc_amount:
                continue
            order.order_line.create({
                "order_id": order.id,
                "name": f"Discount {disc.get('code') or ''}".strip() or "Discount",
                "product_uom_qty": 1,
                "price_unit": -abs(disc_amount),
                "product_id": discount_product.id,
            })

        # Gift card handling (existing logic kept, idempotent)
        if not order.gift_card_applied:
            for gc in order_data.get("applied_gift_cards", []):
                code = gc.get("code")
                amount = _float(gc.get("amount"))

                gift = self.env["shopify.gift.card"].sudo().search(
                    [("code", "=", code)],
                    limit=1
                )
                if gift:
                    gift.balance -= amount

                existing_line = order.order_line.search([
                    ("order_id", "=", order.id),
                    ("gift_card_code", "=", code),
                ], limit=1)

                if not existing_line:
                    order.order_line.create({
                        "order_id": order.id,
                        "name": f"Gift Card ({code})",
                        "product_uom_qty": 1,
                        "price_unit": -amount,
                        "is_gift_card": True,
                        "gift_card_code": code,
                    })

            order.gift_card_applied = True

        # Adjustment to force totals to match Shopify total_price if needed
        shopify_total = _float(order_data.get("total_price"))
        # Recompute amounts using the current Odoo compute helper
        order._compute_amounts()
        delta = round(shopify_total - order.amount_total, 2)
        if delta:
            order.order_line.create({
                "order_id": order.id,
                "name": "Shopify Total Adjustment",
                "product_uom_qty": 1,
                "price_unit": delta,
                "product_id": adjust_product.id,
            })

        # Confirm order if Shopify reports paid/authorized
        financial_status = (order_data.get("financial_status") or "").lower()
        if order.state in ["draft", "sent"] and financial_status in ["paid", "partially_paid", "authorized"]:
            order.action_confirm()

        # If open/invoiced statuses should mark as paid, register payment stub (optional)
        if financial_status in ["paid", "partially_paid"] and order.invoice_status != "invoiced":
            try:
                order._create_invoices()
                for inv in order.invoice_ids:
                    inv.action_post()
            except Exception:
                # Keep silent; payment flow optional
                pass

        return order

    # ---------------------------------------------------
    # SHOPIFY REFUND → GIFT CARD BALANCE RESTORE (UNCHANGED)
    # ---------------------------------------------------
    @api.model
    def apply_shopify_gift_card_refund(self, refund_data):

        order_id = refund_data.get("order_id")
        if not order_id:
            return False

        order = self.search(
            [("shopify_order_id", "=", order_id)],
            limit=1
        )
        if not order:
            return False

        if order.gift_card_refund_processed:
            return True

        for tr in refund_data.get("transactions", []):
            if tr.get("gateway") == "gift_card":
                amount = float(tr.get("amount", 0.0))
                gift = self.env["shopify.gift.card"].sudo().search([], limit=1)
                if gift:
                    gift.balance += amount

        order.gift_card_refund_processed = True
        return True
